import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Container(
    
      child: Row(
        children: <Widget>[
         InkWell(
           child: Text("Home Page"),
           onTap: saveToFirestore,
         )

        ],
      ),
    );
  }

  void saveToFirestore(){

    Firestore.instance.collection('books').add({ 'title': 'title', 'author': 'author','createdAt':FieldValue.serverTimestamp() });
  

  }
}
